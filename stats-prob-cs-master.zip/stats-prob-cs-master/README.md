Course files for 'Statistics and Probability for Computer Science'. 

Full playlist of videos availble here: https://www.youtube.com/playlist?list=PLnd7R4Mcw3rJDOxrwmwyK-EdJl8Tk431H 
